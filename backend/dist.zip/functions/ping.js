import { app } from '@azure/functions';
import { CORRELATION_HEADER, extractCorrelationId, SERVICE_BACKEND, trackGameEventStrict } from '@piquet-h/shared';
export async function ping(request, context) {
    const started = Date.now();
    const correlationId = extractCorrelationId(request.headers);
    const echo = request.query.get('name') || (await safeReadBodyText(request));
    const latencyMs = Date.now() - started;
    // Emit telemetry (room-independent service liveness check) – tolerant if AI not configured.
    trackGameEventStrict('Ping.Invoked', { echo: echo || null, latencyMs }, { correlationId });
    const payload = {
        ok: true,
        status: 200,
        service: SERVICE_BACKEND,
        timestamp: new Date().toISOString(),
        requestId: context.invocationId,
        latencyMs,
        echo: echo || undefined,
        version: process.env.APP_VERSION || undefined
    };
    return {
        status: 200,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Cache-Control': 'no-store',
            [CORRELATION_HEADER]: correlationId
        },
        jsonBody: payload
    };
}
async function safeReadBodyText(request) {
    try {
        const text = await request.text();
        return text?.trim() || undefined;
    }
    catch {
        return undefined;
    }
}
app.http('ping', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: ping
});
//# sourceMappingURL=ping.js.map